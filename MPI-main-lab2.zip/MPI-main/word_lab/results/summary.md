## Sequential baseline

| Run | Time (s) |
|---|---|
| 1 | 6.5481 |
| 2 | 6.9279 |
| 3 | 7.0672 |
| 4 | 6.9767 |
| 5 | 6.3711 |
| **Mean (T_seq)** | **6.7782** (std 0.3017) |

## mpi1 — p = 2

### Total execution time and LI per run

| Run | Total time (s) | LI = max/mean | Spread (max-min)/mean | Check vs baseline |
|---|---|---|---|---|
| 1 | 3.3871 | 1.0141 | 0.0283 | OK |
| 2 | 3.4800 | 1.0208 | 0.0415 | OK |
| 3 | 3.3431 | 1.0335 | 0.0671 | OK |
| 4 | 3.4654 | 1.0102 | 0.0203 | OK |
| 5 | 3.3684 | 1.0265 | 0.0531 | OK |
| **Mean** | **3.4088** (std 0.0606) | **1.0210** | 0.0421 | |

### Local processing time per process (s)

| Rank | Files | MB | Run 1 | Run 2 | Run 3 | Run 4 | Run 5 | Mean |
|---|---|---|---|---|---|---|---|---|
| 0 | 1500 | 140.48 | 3.2849 | 3.4705 | 3.3340 | 3.3888 | 3.3578 | 3.3672 |
| 1 | 1500 | 134.57 | 3.3790 | 3.3293 | 3.1177 | 3.4583 | 3.1842 | 3.2937 |

## mpi2 — p = 2

### Total execution time and LI per run

| Run | Total time (s) | LI = max/mean | Spread (max-min)/mean | Check vs baseline |
|---|---|---|---|---|
| 1 | 3.3814 | 1.0064 | 0.0129 | OK |
| 2 | 3.3124 | 1.0028 | 0.0056 | OK |
| 3 | 3.4349 | 1.0237 | 0.0475 | OK |
| 4 | 3.3977 | 1.0094 | 0.0188 | OK |
| 5 | 3.4341 | 1.0455 | 0.0910 | OK |
| **Mean** | **3.3921** (std 0.0502) | **1.0176** | 0.0352 | |

### Local processing time per process (s)

| Rank | Files | MB | Run 1 | Run 2 | Run 3 | Run 4 | Run 5 | Mean |
|---|---|---|---|---|---|---|---|---|
| 0 | 1499 | 137.53 | 3.3175 | 3.2978 | 3.2622 | 3.3148 | 3.1230 | 3.2631 |
| 1 | 1501 | 137.53 | 3.3605 | 3.2795 | 3.4209 | 3.3778 | 3.4208 | 3.3719 |

## Comparison

T_seq = 6.7782 s

| Version | p | T_p mean (s) | Speedup S_p | Efficiency E_p | Mean LI | Worst LI |
|---|---|---|---|---|---|---|
| mpi1 | 2 | 3.4088 ± 0.0606 | 1.988 | 0.994 | 1.0210 | 1.0335 |
| mpi2 | 2 | 3.3921 ± 0.0502 | 1.998 | 0.999 | 1.0176 | 1.0455 |
